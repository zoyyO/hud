-- Version du manifeste
resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

-- Fonctions exportées
-- Utilisez: exports.target:Target(Distance, Ped)
export "cible"				

-- Scripts clients
client_scripts {
	'client/client.lua',
}

-- Scripts du serveur
server_scripts {
	'@mysql-async/lib/MySQL.lua',     	-- MySQL init
}
