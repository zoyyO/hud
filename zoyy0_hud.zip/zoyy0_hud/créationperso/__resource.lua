-- Version du Manifeste
resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

-- UI
ui_page "ui/index.html"
files {
	"ui/index.html",
	"ui/assets/arrow-left.png",
	"ui/assets/arrow-right.png",
	"ui/assets/radio-check.png",
	"ui/assets/radio-check-black.png",
	"ui/assets/head.png",
	"ui/assets/identity.png",
	"ui/assets/pilosite.png",
	"ui/assets/clothes.png",
	"ui/assets/cursor.png",
	"ui/assets/heritage/Visage-0.jpg",
	"ui/assets/heritage/Visage-1.jpg",
	"ui/assets/heritage/Visage-2.jpg",
	"ui/assets/heritage/Visage-3.jpg",
	"ui/assets/heritage/Visage-4.jpg",
	"ui/assets/heritage/Visage-5.jpg",
	"ui/assets/heritage/Visage-6.jpg",
	"ui/assets/heritage/Visage-7.jpg",
	"ui/assets/heritage/Visage-8.jpg",
	"ui/assets/heritage/Visage-9.jpg",
	"ui/assets/heritage/Visage-10.jpg",
	"ui/assets/heritage/Visage-11.jpg",
	"ui/assets/heritage/Visage-12.jpg",
	"ui/assets/heritage/Visage-13.jpg",
	"ui/assets/heritage/Visage-14.jpg",
	"ui/assets/heritage/Visage-15.jpg",
	"ui/assets/heritage/Visage-16.jpg",
	"ui/assets/heritage/Visage-17.jpg",
	"ui/assets/heritage/Visage-18.jpg",
	"ui/assets/heritage/Visage-19.jpg",
	"ui/assets/heritage/Visage-20.jpg",
	"ui/assets/heritage/Visage-21.jpg",
	"ui/assets/heritage/Visage-22.jpg",
	"ui/assets/heritage/Visage-23.jpg",
	"ui/assets/heritage/Visage-24.jpg",
	"ui/assets/heritage/Visage-25.jpg",
	"ui/assets/heritage/Visage-26.jpg",
	"ui/assets/heritage/Visage-27.jpg",
	"ui/assets/heritage/Visage-28.jpg",
	"ui/assets/heritage/Visage-29.jpg",
	"ui/assets/heritage/Visage-30.jpg",
	"ui/assets/heritage/Visage-31.jpg",
	"ui/assets/heritage/Visage-32.jpg",
	"ui/assets/heritage/Visage-33.jpg",
	"ui/assets/heritage/Visage-34.jpg",
	"ui/assets/heritage/Visage-35.jpg",
	"ui/assets/heritage/Visage-36.jpg",
	"ui/assets/heritage/Visage-37.jpg",
	"ui/assets/heritage/Visage-38.jpg",
	"ui/assets/heritage/Visage-39.jpg",
	"ui/assets/heritage/Visage-40.jpg",
	"ui/assets/heritage/Visage-41.jpg",
	"ui/assets/heritage/Visage-42.jpg",
	"ui/assets/heritage/Visage-43.jpg",
	"ui/assets/heritage/Visage-44.jpg",
	"ui/assets/heritage/Visage-45.jpg",
	"ui/fonts/Circular-Bold.ttf",
	"ui/fonts/Circular-Book.ttf",
	"ui/front.js",
	"ui/script.js",
	"ui/style.css",
	'ui/debounce.min.js'
}

-- Scripts Client
client_scripts {
    'client.lua',
}

-- Scripts Serveur
server_scripts {
    '@mysql-async/lib/MySQL.lua',     -- MySQL init
    'server.lua',
}
