$(document).ready(function(){

  window.addEventListener("message", function(event){
    if(event.data.update == true){
      setProgress(event.data.faim,'.progress-hunger');
      setProgress(event.data.soif,'.progress-thirst');
    }
  });

  // Fonctions
  // Mettre à jour les barres santé/soif
  function setProgress(percent, element){
    $(element).width(percent);
  }
  setProgress(70,'.progress-inventory');

  // Horloge basée sur l'heure locale de l'utilisateur
  function updateClock() {
    var now = new Date(),
        time = (now.getHours()<10?'0':'') + now.getHours() + ':' + (now.getMinutes()<10?'0':'') + now.getMinutes();

    document.getElementById('hour').innerHTML = [time];
    setTimeout(updateClock, 1000);
  }
  updateClock();

});
