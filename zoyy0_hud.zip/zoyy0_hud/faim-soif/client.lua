------------------------------------------------------------------
--                          Variables
------------------------------------------------------------------

local AutoSaveHungerThirst = true             -- Boolean pour mettre à jour la faim / la soif
local AutoSaveHungerThirstTimer = 138000      -- Valeur en ms. Actuellement réglé à 2min30
local showHud = true                          -- Boolean pour afficher / masquer l'HUD
local factorFaim = (1000 * 100) / 2400000     -- Ratio pour consommer la barre de la faim
local factorSoif = (1000 * 100) / 1800000     -- Ratio pour consommer la barre de soif
local faim                                    -- Init la variable de la faim. Défini sur 100 pour le développement. 
local soif                                    -- Init la variable de la soif. Défini sur 100 pour le développement. 

------------------------------------------------------------------
--                          Fonctions
------------------------------------------------------------------

function updateHungerThirstHUD(faim, soif)
  SendNUIMessage({
    update = true,
    faim = faim,
    soif = soif
  })
end

-- Obtenez la vélocité de vitesse pendant que le Joeur cours
function getSpeed()
  local vx,vy,vz = table.unpack(GetEntityVelocity(GetPlayerPed(-1)))
  return math.sqrt(vx*vx+vy*vy+vz*vz)
end

function updateHungerThirst()
  Citizen.Wait(1000) -- Toutes les 1sec
  local ped = GetPlayerPed(-1)

  -- Si plus de faim
  if faim <= 0 then
    faim = 0
    -- Choisissez ce que vous voulez faire ici (dizzy spell, loss of consciousness…)
  end

  -- Si plus de soif
  if soif <= 0 then
    soif = 0
    -- Choisissez ce que vous voulez faire ici (dizzy spell, loss of consciousness…)
  end

  -- Augmenter la faim / la soif si vous courez
  if IsPedOnFoot(ped) then
    local x = math.min(getSpeed(),10) + 1
    if IsPedInMeleeCombat(ped) then           -- Si le Joueur utilise son poing, il consomme plus de faim et de soif qu'en courant
      x = x + 10
      faim = faim - (factorFaim * x)
      soif = soif - (factorSoif * x)
    else                                      -- Si le Joueur cours
      faim = faim - (factorFaim * x)
      soif = soif - (factorSoif * x)
    end
  else
    faim = faim - factorFaim
    soif = soif - factorSoif
  end
end

function RequestToSave()
  TriggerServerEvent("saveHungerThirst", faim, soif)
end


------------------------------------------------------------------
--                          Events
------------------------------------------------------------------

-- Obtenez la faim et la soif du joueur après la connexion pour synchroniser avec HUD
AddEventHandler('playerSpawned', function(spawn)
	TriggerServerEvent("getPlayerHungerThirst")
end)

-- Faim, soif
RegisterNetEvent("PlayerHungerThirst")
AddEventHandler("PlayerHungerThirst", function(result)
  faim = result[1].faim
  soif = result[1].soif
end)

-- Mettre à jour la valeur si elle est utilisée à partir de l'inventaire
RegisterNetEvent("UpdateFoodDrink")
AddEventHandler("UpdateFoodDrink", function(newFaim, newSoif)
  faim = faim + newFaim
  soif = soif + newSoif

  if faim > 100 then faim = 100 end
  if soif > 100 then soif = 100 end
end)

------------------------------------------------------------------
--                          Citizen
------------------------------------------------------------------

-- Afficher le HUD
Citizen.CreateThread(function()
    while true do
      Citizen.Wait(0)
      if showHud then
        updateHungerThirstHUD(faim, soif)
      end
    end
end)

-- Mettre à jour la faim et la soif
Citizen.CreateThread(function()
    while true do
      Citizen.Wait(0)
      SetPlayerHealthRechargeMultiplier(PlayerId(), 0)
      updateHungerThirst()
    end
end)

-- Autosave faim et soif
Citizen.CreateThread(function()
    while true do
      Citizen.Wait(0)
      if AutoSaveHungerThirst then
        Citizen.Wait(AutoSaveHungerThirstTimer)
        RequestToSave()
      end
    end
end)