------------------------------------------------------------------
--                          Variables
------------------------------------------------------------------

local showMenu = false                    
local toggleCoffre = 0
local toggleCapot = 0
local toggleLocked = 0
local playing_emote = false

------------------------------------------------------------------
--                          Fonctions
------------------------------------------------------------------

-- Afficher le réticule (cercle) lorsque le joueur cible des entités (véhicule, piéton…)
function Crosshair(enable)
  SendNUIMessage({
    crosshair = enable
  })
end

-- Basculer le focus (exemple du menu de Vehcile)
RegisterNUICallback('disablenuifocus', function(data)
  showMenu = data.nuifocus
  SetNuiFocus(data.nuifocus, data.nuifocus)
end)

-- Basculer le coffre de la voiture (exemple du menu de Véhicule)
RegisterNUICallback('togglecoffre', function(data)
  if(toggleCoffre == 0)then
    SetVehicleDoorOpen(data.id, 5, false)
    toggleCoffre = 1
  else
    SetVehicleDoorShut(data.id, 5, false)
    toggleCoffre = 0
  end
end)

-- Basculer le capot de la voiture (exemple du menu de Véhicule)
RegisterNUICallback('togglecapot', function(data)
  if(toggleCapot == 0)then
    SetVehicleDoorOpen(data.id, 4, false)
    toggleCapot = 1
  else
    SetVehicleDoorShut(data.id, 4, false)
    toggleCapot = 0
  end
end)

-- Basculer le verrouillage de la voiture (exemple du menu de Véhicule)
RegisterNUICallback('togglelock', function(data)
  if(toggleLocked == 0)then
    SetVehicleDoorsLocked(data.id, 2)
    TriggerEvent('InteractSound_CL:PlayOnOne', 'lock', 1.0)
    Citizen.Trace("Doors Locked")
    toggleLocked = 1
  else
    SetVehicleDoorsLocked(data.id, 1)
    Citizen.Trace("Doors Unlocked")
    TriggerEvent('InteractSound_CL:PlayOnOne', 'unlock', 1.0)
    toggleLocked = 0
  end
end)

-- Exemple d'animation (menu de Ped)
RegisterNUICallback('cheer', function(data)
  playerPed = GetPlayerPed(-1);
		if(not IsPedInAnyVehicle(playerPed)) then
			if playerPed then
				if playing_emote == false then
					TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_CHEERING', 0, true);
					playing_emote = true
				end
			end
		end
end)

------------------------------------------------------------------
--                          Citizen
------------------------------------------------------------------

Citizen.CreateThread(function()
	while true do
    local Ped = GetPlayerPed(-1)

    -- Obtenir des informations sur ce que l'utilisateur cible
    -- /!\ Si cela ne fonctionne pas, vérifiez que vous avez ajouté le dossier "cible" aux ressources et à server.cfg
    local Entity, farCoordsX, farCoordsY, farCoordsZ = exports.target:Target(6.0, Ped)
    local EntityType = GetEntityType(Entity)

    -- Si EntityType est Vehicle
    if(EntityType == 2) then 
      if showMenu == false then
        SetNuiFocus(false, false)
      end
      Crosshair(true)

      if IsControlJustReleased(1, 38) then -- E est appuyer
        showMenu = true
        SetNuiFocus(true, true)
        SendNUIMessage({
          menu = 'vehicle',
          idEntity = Entity
        })
      end
    -- Si EntityType = User
    elseif(EntityType == 1) then 
      if showMenu == false then
        SetNuiFocus(false, false)
      end
      Crosshair(true)

      if IsControlJustReleased(1, 38) then -- E est appuyer
        showMenu = true
        SetNuiFocus(true, true)
        SendNUIMessage({
          menu = 'user',
          idEntity = Entity
        })
      end
    else
      SendNUIMessage({
        menu = false
      })
      SetNuiFocus(false, false)
      Crosshair(false)
    end


    -- Arrêter les émoticônes si l'utilisateur appuie sur E
    -- TODO: Arrêter les émoticônes si l'utilisateur bouge
    if playing_emote == true then
      if IsControlPressed(1, 38) then
        ClearPedTasks(Ped)
        playing_emote = false
      end
    end

    Citizen.Wait(1)
	end
end)